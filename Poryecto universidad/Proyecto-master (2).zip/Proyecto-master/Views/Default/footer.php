</div>

<style>
	html
	{
	    position: relative; 
	    min-height: 100%;
	}

	body
	{
	    margin: 0 0 65px;
	}

	.footer{
		position: absolute;
		bottom: 0;
		width: 100%;
		height: 40px;
		background-color: #000;
		padding-top: 10px;
		text-align: center;
		color: #FFF;
	}
</style>

<div class="footer"> 
	Copyright &copy
</div>

<script type="text/javascript" src="<?php echo URL . VIEWS . DFT; ?>Js/particles.js"></script>
<script type="text/javascript" src="<?php echo URL . VIEWS . DFT; ?>Js/particulas.js"></script>

</body>
</html>