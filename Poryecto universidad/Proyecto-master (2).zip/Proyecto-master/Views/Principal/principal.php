<div class="text-center">
    <h1 class="titulo">
    	<?php 
    		if ($array == 1) {
        		echo "BIENVENIDO ADMINISTRADOR";	
    		} else if ($array == 2) {
    			echo "BIENVENIDO  ADMIN INSTITUCION";	
    		} else if ($array == 3) {
    			echo "BIENVENIDO DOCENTE";
    		}
    	?>
    </h1>
</div>