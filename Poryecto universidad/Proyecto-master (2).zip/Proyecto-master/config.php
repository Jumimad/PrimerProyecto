<?php
const LBS   = 'Library/';
const VIEWS = './Views/';
define('DFT', 'Default/');
define('URL', 'http://localhost/Proyecto/');